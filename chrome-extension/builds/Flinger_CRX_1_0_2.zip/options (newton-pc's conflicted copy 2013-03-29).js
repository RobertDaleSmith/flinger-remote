var backgroundPageWindow = chrome.extension.getBackgroundPage();


var element = document.createElement('textarea');
element.id = 'data';
element.appendChild(document.createTextNode('The man who mistook his wife for a hat'));
document.body.appendChild(element);


console.log("Hey! -Felix")
// Debug
var debug = document.getElementById("debug");
// /Debug

var prevConnection = false;
var prevUrl = "";
var prevHasTag = "000000";
var data = document.getElementById("data");
var docname = document.location.hash.substring(1, 7); // Enter Hashkey - the user's file

function uid() {
    return ("000000" + (Math.random() * Math.pow(36, 6) << 0).toString(36)).substr(-6);
};

function keyCodeUid() {
    return ("" + (Math.random() * Math.pow(36, 8) << 0)).substr(-8);
};

var $state;

function openDocument(docName) {
    console.log("Connecting to " + docname);




    sharejs.open(docName, 'json', 'http://flingerbeta.cloudapp.net/channel', function (error, shareDocument) {
        $state = shareDocument;


        shareDocument.on('change', function (op) {
            //stateUpdated(op)
            console.log(op);
        })
        if (shareDocument.created) {
            //clear()
            shareDocument.submitOp([{p:[], od:null, oi:'hi'}]);
            console.log("dddddddd");
        } else {
            //stateUpdated()
            console.log("gggggggg");
        }


        if (error) {

            data.content = error;
            console.log("Connecting error " + error);

        } else {
            //Connection successful
            console.log("Connected to " + docName);
            document.getElementById('loaderImage').style.display = 'none';
            document.getElementById('intro_paired_not_box').style.display = 'none';
            document.getElementById('intro_paired_yes_box').style.display = 'block';

            document.getElementById('control_container').style.display = 'block';
            //WinJS.UI.Animation.enterPage(control_container);

            document.getElementById('paired_Title').innerHTML = "Paired to #" + docName;

            document.getElementById('intro_tv_url').innerHTML = "http://tv.flinger.co/#" + docName;
            document.getElementById('intro_tv_url').href = "http://tv.flinger.co/#" + docName;

            //LocalStorage
            //localSettings.values["connectedHash"] = docName;

            // Attaching the ShareJS file to the editor
            //shareDocument.attach_textarea(data);
            prevConnection = true;
            prevHasTag = docName;





        }

    });
};

function connectToHash() {

    docname = document.getElementById("hashtag_input").value;


    if (docname.length != 6) {
        //Input validation. Must be 6 alphanumeric characters or shake and error displayed.

        document.getElementById('intro_error_label').style.display = 'block';
        //WinJS.UI.Animation.enterContent(intro_error_label);
        setTimeout(function () {
            //WinJS.UI.Animation.exitPage(intro_error_label);

        }, 3000);

        //WinJS.UI.Animation.swipeReveal(hashtag_input, { top: "0px", left: "5px", rtlflip: true });
        //WinJS.UI.Animation.swipeReveal(connect_button, { top: "0px", left: "5px", rtlflip: true });
        setTimeout(function () {
            //WinJS.UI.Animation.swipeReveal(hashtag_input, { top: "0px", left: "-4px", rtlflip: true });
            //WinJS.UI.Animation.swipeReveal(connect_button, { top: "0px", left: "-4px", rtlflip: true });
            setTimeout(function () {
                //WinJS.UI.Animation.swipeReveal(hashtag_input, { top: "0px", left: "3px", rtlflip: true });
                //WinJS.UI.Animation.swipeReveal(connect_button, { top: "0px", left: "3px", rtlflip: true });
                setTimeout(function () {
                    //WinJS.UI.Animation.swipeReveal(hashtag_input, { top: "0px", left: "-2px", rtlflip: true });
                    //WinJS.UI.Animation.swipeReveal(connect_button, { top: "0px", left: "-2px", rtlflip: true });
                    setTimeout(function () {
                        //WinJS.UI.Animation.swipeReveal(hashtag_input, { top: "0px", left: "0px", rtlflip: true });
                        //WinJS.UI.Animation.swipeReveal(connect_button, { top: "0px", left: "0px", rtlflip: true });
                    }, 100);
                }, 100);
            }, 100);
        }, 100);


        // document.getElementById('hashtag_input').className = "shake";
        //  document.getElementById('connect_button').className = "shake";
    }
    else {
        document.getElementById('disconnect_button').style.display = 'block';
        document.getElementById('loaderImage').style.display = 'block'

        document.getElementById('hashtag_input').disabled = 'true';

        docname = docname.toLowerCase();
        document.getElementById("hashtag_input").value = docname;

        document.location.hash = docname;
        console.log("Tryin to open " + docname);
        openDocument(docname);
    }


};

function disconnectFromHash() {

    console.log("Disconnecting from " + prevHasTag);
    document.getElementById('hashtag_input').disabled = 'false';
    document.getElementById('loaderImage').style.display = 'block';

    //WinJS.UI.Animation.exitPage(control_container);

    sharejs.open(prevHasTag, 'text', 'http://flingerbeta.cloudapp.net/channel', function (error, shareDocument) {
        if (error) {
            console.log("Disconnected error");
            data.content = error;
        } else {
            shareDocument.close();
            console.log("Disconnected from " + prevHasTag);
            document.getElementById('loaderImage').style.display = 'none';
            document.getElementById('disconnect_button').style.display = 'none';

            document.getElementById('loaderImage').style.display = 'none';
            document.getElementById('intro_paired_not_box').style.display = 'block';
            document.getElementById('intro_paired_yes_box').style.display = 'none';


            //localSettings.values.remove("connectedHash");

            document.location.reload(true);
        }

    });
    prevConnection = false;
    //localSettings.values["recentDisconnect"] = true;


    document.getElementById("hashtag_input").value = "";




};


var textArea = document.getElementById("data");
var textAreaPrevText = textArea.value;
var myVar = setInterval(function () { myTimer() }, 250);

function myTimer() {

    var url = "";
    var textArea = document.getElementById("data");

    var json = textArea.value; //'{"url":"http://www.youtube.com/watch?v=iKiFKXYu0HY","keycode":"PLAY"}'
    var obj;




    updateFromInput();
    textAreaPrevText = textArea.value;
    if (textAreaPrevText != textArea.value) {

    }




    //if (appView.value === appViewState.snapped) {
    //    document.getElementById("header_container").style.left = "15px";

    //    document.getElementById("intro_container").style.left = "15px";
    //    document.getElementById("intro_container").style.width = "285px";
    //    document.getElementById("intro_container").style.height = "285px";

    //    document.getElementById("control_container").style.left = "15px";
    //    document.getElementById("control_container").style.width = "285px";

    //    document.getElementById("addressBarTextArea").style.width = "250px";

    //    document.getElementById("hashtag_input").style.left = "15px";
    //    document.getElementById("hashtag_input").style.width = "251px";

    //    document.getElementById("disconnect_button").style.left = "150px";

    //    document.getElementById("connect_button").style.left = "180px";

    //    document.getElementById("paired_Title").style.fontSize = "25px";
    //    document.getElementById("paired_Title").style.top = "-2px";

    //    document.getElementById("paired_Label1").style.display = "none";
    //    document.getElementById("paired_Label2").style.display = "none";

    //    document.getElementById("intro_1_text").innerHTML = "On your TV, go to";

    //    document.getElementById("intro_tv_url").style.left = "15px";
    //    document.getElementById("intro_tv_url").style.top = "62px";
    //    document.getElementById("intro_tv_url").style.fontSize = "20px";

    //    document.getElementById("loaderImage").style.left = "240px";
    //    document.getElementById("loaderImage").style.top = "10px";

    //}
    //else {
    //    document.getElementById("header_container").style.left = "120px";

    //    document.getElementById("intro_container").style.left = "120px";
    //    document.getElementById("intro_container").style.width = "640px";

    //    document.getElementById("control_container").style.left = "120px";
    //    document.getElementById("control_container").style.width = "640px";

    //    document.getElementById("addressBarTextArea").style.width = "605px";

    //    document.getElementById("hashtag_input").style.left = "60px";
    //    document.getElementById("hashtag_input").style.width = "271px";

    //    document.getElementById("disconnect_button").style.left = "220px";

    //    document.getElementById("connect_button").style.left = "245px";

    //    document.getElementById("paired_Title").style.fontSize = "30px";
    //    document.getElementById("paired_Title").style.top = "-8px";

    //    document.getElementById("paired_Label1").style.display = "block";
    //    document.getElementById("paired_Label2").style.display = "block";

    //    document.getElementById("intro_1_text").innerHTML = "To get started, open your smart TV's browser and go to";

    //    document.getElementById("intro_tv_url").style.left = "62px";
    //    document.getElementById("intro_tv_url").style.top = "56px";
    //    document.getElementById("intro_tv_url").style.fontSize = "30px";

    //    document.getElementById("loaderImage").style.left = "355px";
    //    document.getElementById("loaderImage").style.top = "162px";


    //}

}

function updateFromInput() {

    var url = "";
    var textArea = document.getElementById("data");

    var json = textArea.value; //'{"url":"http://www.youtube.com/watch?v=iKiFKXYu0HY","keycode":"PLAY"}'
    var obj;

    if (IsJsonString(json)) {
        obj = JSON.parse(json);

        if (obj.url)
            url = obj.url;

    }

    if (prevUrl != url) {
        document.getElementById('addressBarTextArea').value = url;
    }


    prevUrl = url;

}

function flingURI() {
    var newUrl = document.getElementById('addressBarTextArea').value;
    document.getElementById("data").value = "{\"url\":\"" + newUrl + "\",\"keycode\":\"NEW_URL\"}"

    document.getElementById("data").select();

    setTimeout(function () {
        document.getElementById("data").blur();
        document.getElementById('addressBarTextArea').select();
    }, 250);
};

function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}


//function registerForShare() {
//    var dataTransferManager = Windows.ApplicationModel.DataTransfer.DataTransferManager.getForCurrentView();
//    dataTransferManager.addEventListener("datarequested", shareLinkHandler);
//}

//function shareLinkHandler(e) {
//    var request = e.request;
//    request.data.properties.title = "Share Link to Flinger TV Mode";
//    request.data.properties.description = "Don't watch Flinger alone. Invite friends to watch Flinger with you, and fling videos to everyones' TV screen at once. Or have your friends fling videos to your screen.";

//    var hashUrl = document.getElementById("intro_tv_url").innerHTML;

//    //if (localSettings.values["connectedHash"]) {

//    //    hashUrl = "http://tv.flinger.co/#" + localSettings.values["connectedHash"];
//    //}

//    request.data.setUri(new Windows.Foundation.Uri(hashUrl));
//}
//registerForShare();

function alphaFilterKeypress(evt) {
    evt = evt || window.event;
    var charCode = evt.keyCode || evt.which;
    var charStr = String.fromCharCode(charCode);
    return /[a-z0-9_]/i.test(charStr);
}

window.onload = function () {
    var input = document.getElementById("hashtag_input");
    input.onkeypress = alphaFilterKeypress;
};

var cSpeed = 5;
var cWidth = 32;
var cHeight = 32;
var cTotalFrames = 75;
var cFrameWidth = 32;
var cImageSrc = 'images/sprites.png';

var cImageTimeout = false;

function startAnimation() {

    document.getElementById('loaderImage').innerHTML = '<canvas id="canvas" width="' + cWidth + '" height="' + cHeight + '"><p>Your browser does not support the canvas element.</p></canvas>';

    //FPS = Math.round(100/(maxSpeed+2-speed));
    FPS = Math.round(100 / cSpeed);
    SECONDS_BETWEEN_FRAMES = 1 / FPS;
    g_GameObjectManager = null;
    g_run = genImage;

    g_run.width = cTotalFrames * cFrameWidth;
    genImage.onload = function () { cImageTimeout = setTimeout(fun, 0) };
    initCanvas();
}


function imageLoader(s, fun)//Pre-loads the sprites image
{
    clearTimeout(cImageTimeout);
    cImageTimeout = 0;
    genImage = new Image();
    genImage.onload = function () { cImageTimeout = setTimeout(fun, 0) };
    genImage.onerror = new Function('console.log(\'Could not load the image\')');
    genImage.src = s;
}

//The following code starts the animation
new imageLoader(cImageSrc, 'startAnimation()');




function playVideo() {
    var url = "";
    var textArea = document.getElementById("data");

    var json = textArea.value;
    var obj;

    if (IsJsonString(json)) {
        obj = JSON.parse(json);

        if (obj.url)
            url = obj.url;
    }

    document.getElementById("data").value = "{\"url\":\"" + url + "\",\"keycode\":\"VIDEO_PLAY_" + keyCodeUid() + "\"}";
    document.getElementById("data").select();

    setTimeout(function () {
        document.getElementById("data").blur();
        document.getElementById('addressBarTextArea').select();
    }, 250);
}

function pauseVideo() {
    var url = "";
    var textArea = document.getElementById("data");

    var json = textArea.value;
    var obj;

    if (IsJsonString(json)) {
        obj = JSON.parse(json);

        if (obj.url)
            url = obj.url;
    }



    document.getElementById("data").value = "{\"url\":\"" + url + "\",\"keycode\":\"VIDEO_PAUSE_" + keyCodeUid() + "\"}";
    document.getElementById("data").select();

    setTimeout(function () {
        document.getElementById("data").blur();
        document.getElementById('addressBarTextArea').select();
    }, 250);
}

var volumeMute = false;

function toggleMute() {
    var url = "";
    var textArea = document.getElementById("data");

    var json = textArea.value;
    var obj;

    if (IsJsonString(json)) {
        obj = JSON.parse(json);

        if (obj.url)
            url = obj.url;
    }

    var innerHTML = "";
    if (volumeMute) {
        innerHTML = "{\"url\":\"" + url + "\",\"keycode\":\"VIDEO_VOLMAX_" + keyCodeUid() + "\"}";
        document.getElementById("muteVideoBtn").className = "mute_Video_Btn";

        volumeMute = false;
    }
    else {
        innerHTML = "{\"url\":\"" + url + "\",\"keycode\":\"VIDEO_MUTE_" + keyCodeUid() + "\"}";
        document.getElementById("muteVideoBtn").className = "volmax_Video_Btn";
        volumeMute = true;
    }

    document.getElementById("data").value = innerHTML;
    document.getElementById("data").select();

    setTimeout(function () {
        document.getElementById("data").blur();
        document.getElementById('addressBarTextArea').select();
    }, 250);
}



// Add event listeners once the DOM has fully loaded by listening for the
// `DOMContentLoaded` event on the document, and adding your listeners to
// specific elements when it triggers.
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('connect_button').addEventListener('click', connectToHash);
    document.getElementById('disconnect_button').addEventListener('click', disconnectFromHash);
   
    document.getElementById('hashtag_input').addEventListener('keydown', pinInputChangeListener);
    document.getElementById('addressBarTextArea').addEventListener('keypress', addressBarChangeListener);
    document.getElementById('data').addEventListener('keydown', dataTextAreaChangeListener);

    document.getElementById('fling_button').addEventListener('click', flingURI);

    document.getElementById('muteVideoBtn').addEventListener('click', toggleMute);
    document.getElementById('pauseVideoBtn').addEventListener('click', pauseVideo);
    document.getElementById('playVideoBtn').addEventListener('click', playVideo);
});

function pinInputChangeListener() {
    if (event.keyCode == 13) document.getElementById('connect_button').click();
}
function addressBarChangeListener() {
    if (event.keyCode == 13) document.getElementById('fling_button').click();
}
function dataTextAreaChangeListener() {
    if(event.keyCode==13){return false;}
}