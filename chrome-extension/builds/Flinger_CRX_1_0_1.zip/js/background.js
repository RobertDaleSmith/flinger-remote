var docname;
var $state;
var sessionActive = false;
var prevConnection = false;
var prevUrl = "";
var prevHasTag = "000000";
var currentVolume = 100;
var stateUpdated = null;
var remoteName = "";

function keyCodeUid() {
    return ("" + (Math.random() * Math.pow(36, 8) << 0)).substr(-8);
};
function viewerUid() {
    return ("" + (Math.random() * Math.pow(36, 4) << 0)).substr(-4);
};

var newUrl = "";

function flingURI() {
    
    if( youtube_parser(newUrl) != 0 )
        keyCodeToSend = "VIDEO_NEW_" + keyCodeUid();
    else
        keyCodeToSend = "URL_NEW_" + keyCodeUid();

    if (  !(newUrl.indexOf('http://') !== -1) && !(newUrl.indexOf('https://') !== -1)  )
        newUrl = "http://" + newUrl;
    $state.submitOp([{p:['url'],     od:null, oi:newUrl       },
                     {p:['keyCode'], od:null, oi:keyCodeToSend}]);
    
                    
};

function bgpStateUpdate() {

    if(stateUpdated != null)
        stateUpdated();
   


    try {
        if (JSON.stringify($state.at('remotes').get()[getRemoteIndex(remoteName)].active) == 0) {
            $state.submitOp([{ p: ['remotes', getRemoteIndex(remoteName), 'active'], od: null, oi: 1}]);
        }
    }
    catch (e) { }


}

var openDocument = function (docName) {
    docname = docName;
    console.log("Connecting to " + docname);

    //local-testing:  http://localhost:36464/     //online-testing: http://flinger.cloudapp.net/
    sharejs.open(docname, 'json', 'http://flinger.cloudapp.net/channel', function (error, shareDocument) {
        $state = shareDocument;

        shareDocument.on('change', function (op) {

            //console.log(JSON.stringify(op));

            bgpStateUpdate();

        });
        remoteName = "Remote" + viewerUid();
        if (shareDocument.created) {

            $state.submitOp([{ p: [], od: null, oi: { url: "", keyCode: "", volume: 100, seekTo: 0, screens: [], remotes: [{ name: remoteName, active: 1}]}}]);
            console.log("Document" + " " + docname + " " + "Created!");

        } else {
            $state.submitOp([{ p: ['remotes', getRemoteCount()], li: { name: remoteName, active: 1}}]);
            console.log("Document" + " " + docname + " " + "Opened!");

        }

        if (error) {
            sessionActive = false;
            data.content = error;
            console.log("Connecting error " + error);

        } else {
            sessionActive = true;
            $('#data').text(JSON.stringify($state.snapshot));
            if(stateUpdated != null)
                stateUpdated();

            //Connection successful
            console.log("Connected to " + docname);

            //LocalStorage
            //localSettings.values["connectedHash"] = docname;

            prevConnection = true;
            prevHasTag = docname;
            
            localStorage.setItem('saved-hash-id', docname);




        }

    });
};

function youtube_parser(url) {
    url = url.replace("player_embedded&v=", "watch?v=");
    var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
    var match = url.match(regExp);

    if (match && match[7].length == 11) {

        return match[7];
    } else {
        //alert("Url incorrecta");
        return 0;
    }
}


window.onload = function () {

    var savedHashId = localStorage.getItem('saved-hash-id');
    if (savedHashId != null && !sessionActive) {
        docname = savedHashId;
        prevHasTag = savedHashId;
        prevConnection = true;
        
        
        console.log('Restored hash id: #' + docname);
    }

    if (prevConnection)
        openDocument(prevHasTag);

    var notConnectedMessage = "Fling was not sent because you are not paired to a Flinger channel.";

    chrome.contextMenus.removeAll();

    // A link onclick callback function.
    var linkOnClick = function (info, tab) {
        console.log("item " + info.menuItemId + " was clicked");
        console.log("info: " + JSON.stringify(info));
        console.log("tab: " + JSON.stringify(tab));
        if (sessionActive) {
            newUrl = info.linkUrl;
            flingURI();

            //sendGAEvent("Fling", "Link");
        }
        else {
            console.log("Fling was not sent because you are not paired to a Flinger channel.");
            chrome.tabs.create({ url: "options.html" });
            window.alert(notConnectedMessage);
            //TODO: Notify user no devices paired.
        }

    };
    var linkId = chrome.contextMenus.create({ "title": "Fling Link to Flinger.co", "contexts": ["link"], "onclick": linkOnClick });
    console.log("'" + "link" + "' item:" + linkId);


    // A page onclick callback function.
    var pageOnClick = function (info, tab) {
        console.log("item " + info.menuItemId + " was clicked");
        console.log("info: " + JSON.stringify(info));
        console.log("tab: " + JSON.stringify(tab));
        if (sessionActive) {
            newUrl = tab.url;
            flingURI();

            //sendGAEvent("Fling", "Link");
        }
        else {
            console.log("Fling was not sent because you are not paired to a Flinger channel.");
            chrome.tabs.create({ url: "options.html" });
            window.alert(notConnectedMessage);
            //TODO: Notify user no devices paired.
        }

    };

    var pageId = chrome.contextMenus.create({ "title": "Fling Page to Flinger.co", "contexts": ["page"], "onclick": pageOnClick });
    console.log("'" + "page" + "' item:" + pageId);



    // A image onclick callback function.
    var imageOnClick = function (info, tab) {
        console.log("item " + info.menuItemId + " was clicked");
        console.log("info: " + JSON.stringify(info));
        console.log("tab: " + JSON.stringify(tab));
        if (sessionActive) {
            newUrl = info.srcUrl;
            flingURI();

            //sendGAEvent("Fling", "Link");
        }
        else {
            console.log("Fling was not sent because you are not paired to a Flinger channel.");
            chrome.tabs.create({ url: "options.html" });
            window.alert(notConnectedMessage);
            //TODO: Notify user no devices paired.
        }

    };

    var imageId = chrome.contextMenus.create({ "title": "Fling Image to Flinger.co", "contexts": ["image"], "onclick": imageOnClick });
    console.log("'" + "image" + "' item:" + imageId);
}


var remoteCount = 0, remoteListCounted = false;
var remotesObject = [];
function getRemoteCount() {
    remoteCount = 0; remoteListCounted = false;

    try {
        remotesObject = $state.at('remotes').get();
    } catch (e) {
        console.log("Warning: Remotes object not found.");
    }

    remoteCount = remotesObject.length;
    //console.log(remoteCount);
    return remoteCount;
};

function getRemoteIndex(name) {
    foundIndex = -1;
    var remotes = getRemoteCount();
    for (var i = 0; i < remotes; i++) {
        try {
            if (JSON.stringify($state.at('remotes').get()[i].name).indexOf("\"" + name + "\"") !== -1) {
                foundIndex = i;
                break;
            }
        }
        catch (e) { }
    }

    return foundIndex;
};

// Called when the user clicks on the browser action.
chrome.browserAction.onClicked.addListener(function(tab) {
    var action_url = "options.html";// + encodeURIComponent(tab.href) + '&title=' + encodeURIComponent(tab.title);
    chrome.tabs.create({ url: action_url });
});