google_ad_client = "ca-pub-1646526831713630";
/* remote.flinger.co */
google_ad_slot = "4409770666";
google_ad_width = 320;
google_ad_height = 50;